#include <wiringPi.h>
#include <stdio.h>
#include <stdlib.h>
 
#define Pin	25
#define delay_time 120
int LED[3]={0,1,2};
char i,idx,cnt;
char count;
char data[4];
 
static int flag = 0;
int exec_cmd(char key_val)
{
    switch(key_val) {
        case 0x45://1
            digitalWrite(LED[0],HIGH);
            digitalWrite(LED[1],LOW);
            digitalWrite(LED[2],LOW);
            break;
        case 0x46://2
            digitalWrite(LED[0],LOW);
            digitalWrite(LED[1],HIGH);
            digitalWrite(LED[2],LOW);
            break;
        case 0x47://3
            digitalWrite(LED[0],LOW);
            digitalWrite(LED[1],LOW);
            digitalWrite(LED[2],HIGH);
            break;
        default:
            digitalWrite(LED[0],LOW);
            digitalWrite(LED[1],LOW);
            digitalWrite(LED[2],LOW);
            break;
    }
 
    return 0;
}

void setup()
{
	int i;
	pinMode(Pin, INPUT);
	for(i=0;i<3;i++)
	{
		pinMode(LED[i], OUTPUT);
	}
}
 
int main(int argc, char const *argv[])
{
    if(wiringPiSetup() == -1){ //when initialize wiring failed,print messageto screen
		printf("failed !");
		return 1; 
	}
	setup();
 
    while (1) {
        if (digitalRead(Pin) == LOW) {
            count = 0;
            while (digitalRead(Pin) == LOW && count++ < 200)   //9ms
                delayMicroseconds(delay_time);
            count = 0;
            while (digitalRead(Pin) == HIGH && count++ < 80)    //4.5ms
                delayMicroseconds(delay_time);
            idx = 0;
            cnt = 0;
            data[0]=0;
            data[1]=0;
            data[2]=0;
            data[3]=0;
            for (i =0;i<32;i++) {
                count = 0;
                while (digitalRead(Pin) == LOW && count++ < 15)  //0.56ms
                    delayMicroseconds(delay_time);
                 
                count = 0;
                while (digitalRead(Pin) == HIGH && count++ < 40) //0: 0.56ms; 1: 1.69ms delayMicroseconds(60); if (count > 25)
                    delayMicroseconds(delay_time);
                if (count > 8)
                    data[idx] |= 1<<cnt;
                if (cnt== 7) {
                    cnt=0;
                    idx++;
                } else {
                    cnt++;
                }
                if ((data[0]+data[1] == 0xFF) && (data[2]+data[3]==0xFF)) {    //check 
                    printf("Get the key: 0x%02x\n",data[2]);
                    exec_cmd(data[2]);
                }
            }
        }
    }
    return 0;
}
