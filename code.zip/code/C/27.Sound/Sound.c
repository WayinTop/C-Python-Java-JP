#include <wiringPi.h>
#include <stdio.h>

#define ledPin    0  	//define the ledPin
#define soundPin 1		//define the sensorPin

int main(void)
{
	if(wiringPiSetup() == -1){ //when initialize wiring failed,print messageto screen
		printf("failed !");
		return 1; 
	}
	
	pinMode(ledPin, OUTPUT); 
	pinMode(soundPin, INPUT);

	while(1){
		printf("shock:\n");
		if(digitalRead(soundPin) == HIGH){ //if read sensor for high level
			digitalWrite(ledPin, HIGH);   //led on
			printf("LED...HIGH\n");
		}
		else {				
			digitalWrite(ledPin, LOW);   //led off
			printf("LED...LOW\n");
		}
		delay(500);
	}

	return 0;
}
